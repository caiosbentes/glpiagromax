

- Antes de instalar remova qualquer versão anterior do plugin.


- Before install remove any previous versions of plugin.
